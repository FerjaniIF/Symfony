<?php

namespace App\Controller;

use App\Form\ArticleType; use App\Entity\Article;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use App\Entity\Category; use App\Form\CategoryType;
use App\Entity\PropertySearch; use App\Form\PropertySearchType;
use App\Entity\CategorySearch; use App\Form\CategorySearchType;
use App\Entity\PriceSearch; use App\Form\PriceSearchType;


class IndexController extends AbstractController
{
    private $entityManager;
    private $doctrine;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    #[Route("/", name: "article_list")]
    public function home(Request $request)
    {
        $propertySearch = new PropertySearch(); 
        $form = $this->createForm(PropertySearchType::class,$propertySearch); 
        $form->handleRequest($request);  
        $articles= [];
        if($form->isSubmitted() && $form->isValid()) {
            $Nom = $propertySearch->getNom(); 
            if ($Nom!="")
                $articles= $this->entityManager->getRepository(Article::class)->findBy(['Nom' => $Nom] );
            else
                $articles = $this->entityManager->getRepository(Article::class)->findAll();
        }
        return $this->render('articles/index.html.twig',[ 'form' =>$form->createView(), 'articles' => $articles]);
    }

    #[Route("/article/save", name: "app_index_save", methods: ["GET"])]
    public function save(Request $request)
    {
        $article = new Article();
        $article->setNom('Article 2');
        $article->setPrix(858525);
        
        $this->entityManager->persist($article);
        $this->entityManager->flush();

        return new Response('Article enregistré avec id ' . $article->getId());
    }


    #[Route("/article/new", name: "new_article", methods: ["GET", "POST"])]
    public function new(Request $request) { 
        $article = new Article(); 
        $form = $this->createForm(ArticleType::class, $article); 
        $form->handleRequest($request); 
        if ($form->isSubmitted() && $form->isValid()) { 
            $article = $form->getData(); 
            $this->entityManager->persist($article); 
            $this->entityManager->flush(); 
            return $this->redirectToRoute('article_list'); 
        } 
        return $this->render('articles/new.html.twig', ['form' => $form->createView()]); 
    }

    #[Route("/article/{id}", name: "article_show")]
    public function show(int $id): Response
    {
        $article = $this->entityManager->getRepository(Article::class)->find($id);

        if (!$article) {
            throw $this->createNotFoundException('Article not found');
        }

        return $this->render('articles/show.html.twig', [
            'article' => $article,
        ]);
    }

    #[Route("/article/edit/{id}", name: "edit_article" , methods: ["GET", "POST"])]
    public function edit(Request $request, $id) { 
        $article = new Article(); 
        $article = $this->entityManager->getRepository(Article::class)->find($id); 
        $form = $this->createForm(ArticleType::class,$article); 
        $form->handleRequest($request); 
        if($form->isSubmitted() && $form->isValid()) { 
            $this->entityManager->flush(); 
            return $this->redirectToRoute('article_list'); 
        } 
        return $this->render('articles/edit.html.twig', ['form' => $form->createView()]); 
    }

    
    #[Route("/article/delete/{id}", name: "delete_article")]
    public function delete(Request $request, $id) { 
        $article = $this->entityManager->getRepository(Article::class)->find($id); 
        $this->entityManager->remove($article); 
        $this->entityManager->flush(); 
        $response = new Response(); 
        $response->send(); 
        return $this->redirectToRoute('article_list'); 
    }

    #[Route("/category/newCat", name: "new_category" , methods: ["GET", "POST"])] 
    public function newCategory(Request $request) { 
        $category = new Category(); 
        $form = $this->createForm(CategoryType::class,$category); 
        $form->handleRequest($request); 

        if($form->isSubmitted() && $form->isValid()) { 
            $article = $form->getData();
            $this->entityManager->persist($category); 
            $this->entityManager->flush(); 
        } 
        return $this->render('articles/newCategory.html.twig',['form'=> $form->createView()]); 
    }

    #[Route("/art_cat", name: "article_par_cat" , methods: ["GET", "POST"])] 
    public function articlesParCategorie(Request $request) { 
        $categorySearch = new CategorySearch(); 
        $form = $this->createForm(CategorySearchType::class,$categorySearch); 
        $form->handleRequest($request); 
        $articles= [];
        if($form->isSubmitted() && $form->isValid()) { 
            $category = $categorySearch->getCategory(); 
            if ($category!="") 
                $articles= $category->getArticles(); 
            else 
                $articles= $this->entityManager->getRepository(Article::class)->findAll(); 
        } 
        return $this->render('articles/articlesParCategorie.html.twig',['form' => $form->createView(),'articles' => $articles]); 
    }

    #[Route("/art_prix", name: "article_par_prix" , methods: ["GET", "POST"])] 
    public function findByPriceRange (Request $request) { 
        $priceSearch = new PriceSearch(); 
        $form = $this->createForm(PriceSearchType::class,$priceSearch); 
        $form->handleRequest($request); 
        $articles= []; 
        if($form->isSubmitted() && $form->isValid()) { 
            $minPrice = $priceSearch->getMinPrice(); 
            $maxPrice = $priceSearch->getMaxPrice(); 
            $articles= $this->entityManager-> getRepository(Article::class)->findByPriceRange($minPrice,$maxPrice); 
        } 
        return $this->render('articles/articlesParPrix.html.twig',[ 'form' =>$form->createView(), 'articles' => $articles]); 
    }
  
}
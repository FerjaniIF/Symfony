<?php

namespace App\Entity;

use App\Repository\ArticleRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

#[ORM\Entity(repositoryClass: ArticleRepository::class)]
class Article
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[\Doctrine\ORM\Mapping\Column(type: "integer")]
    private ?int $id = null;
    
    #[\Doctrine\ORM\Mapping\Column(type: "string", length: 255, nullable: false)]
    #[\Symfony\Component\Validator\Constraints\Length(
        min: 5,
        max: 50,
        minMessage: "Le nom d'un article doit comporter au moins {{ limit }} caractères",
        maxMessage: "Le nom d'un article doit comporter au plus {{ limit }} caractères"
    )]
    private string $Nom;

    #[\Doctrine\ORM\Mapping\Column(type: "decimal", precision: 10, scale: 0, nullable: false)]
    #[\Symfony\Component\Validator\Constraints\NotEqualTo(
        value: 0,
        message: "Le prix d'un article ne doit pas être égal à 0"
    )]
    private string $Prix;

    #[ORM\ManyToOne(targetEntity: "App\Entity\Category", inversedBy: "articles")]
    #[ORM\JoinColumn(nullable: false)]
    private Category $category;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->Nom;
    }

    public function setNom(string $Nom): static
    {
        $this->Nom = $Nom;

        return $this;
    }

    public function getPrix(): ?string
    {
        return $this->Prix;
    }

    public function setPrix(string $Prix): static
    {
        $this->Prix = $Prix;

        return $this;
    }

    public function getCategory(): ?Category
    {
        return $this->category;
    }

    public function setCategory(?Category $category): self
    {
        $this->category = $category;

        return $this;
    }
}
